import java.util.*;
import java.io.File;

public class Flyer{
	static String fname = "../test/flyer.txt";
	//static String fname = "flyer.txt";
	static String[][] a; static int na;
	public static void main(String[] args)throws Exception{
		checkData();
		Scanner sc = new Scanner(new File(fname)); int prob=1;
		while(true){
			na = sc.nextInt(); if(na<=0) break;
			sc.nextLine(); //get past end-of-line
			a = new String[1000][];
			for(int i=0;i<na;i++){
				String line = sc.nextLine(); 
				a[i] = line.split("[ ]+");
			}
			int[] min = new int[na]; Arrays.fill(min,-1);
			int here = idx("Vermillion");
			if(here>=0) min[here]=0;
			int ct=0, ans=-1; 
			while( ans==-1 && ct<100 ){
				ct++;
				for(int i=0; i<na; i++) if(min[i]==ct-1){
					for(int j=1; j<a[i].length; j++){
						if(a[i][j].equals("Paris")) ans = ct;
						int id = idx(a[i][j]); if(id<0 || min[id]!=-1) continue;
						min[id] = ct;
					}
				}
			}
			String out = ans<0 ? "Not Possible" : ""+ans; 
			System.out.println("Problem "+(prob++)+": "+out);		
		}
	}
	static int idx(String s){ 
		for(int i=0;i<na; i++) 
			if(a[i][0].equals(s)) return i;
		return -1;  //not found
	}
	//just n (1..20), then n lines. n distinct first cities, 1..5 dest Ulll(2..10)
	static void checkData() throws Exception{
		Scanner sc = new Scanner(new File(fname));
		while(true){		
			String num = sc.nextLine(); 
			if(canTrim(num)) throw new Exception("a");
			int n = Integer.parseInt(num); 
			if(n==0 && sc.hasNext()) throw new Exception("trailing space");
			if(n==0) return;
			
			if(n<1 || n>20) throw new Exception("b"+n);
			String[][] a = new String[n][];
			for(int i=0;i<n;i++){
				String line = sc.nextLine(); if(canTrim(line)) throw new Exception("a"+i);
				a[i] = line.split("[ ]");
				if(a[i].length < 2 || a[i].length > 6) throw new Exception("b"+i);
				for(int j=0;j<i;j++) if(a[j][0].equals(a[i][0])) throw new Exception("c"+i);
				for(int k=0; k<a[i].length; k++) if(!ok(a[i][k]))throw new Exception("d"+i+k);
			}
		}			
	}
	static boolean ok(String x){
		if(x.length()<2 || x.length()>10) return false;
		char ch = x.charAt(0); if(ch<'A' || ch>'Z') return false;
		for(int i=1;i<x.length(); i++){
			ch=x.charAt(i); if(ch<'a' || ch>'z') return false;
		}
		return true;
	}
	static boolean canTrim(String x){ return x.length() > x.trim().length();}	
}