#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

const double PI = 3.141592653589793;

double vol(double r){
	return (4.0/3.0) * PI * r * r * r;
}

int main(int argc, char** argv){
	ifstream fin("../test/snow.txt");
	int nProbs = 0;
	fin >> nProbs;
	while(nProbs > 0){
		int totalVol;
		fin >> totalVol;
		double lo = 0.0; 
		double hi = 1000000000.0;
		double r = 0.0;
		for(int i=0; i < 100; ++i){
			r = (lo + hi) / 2.0;
			if(vol(r) + vol(r+1) + vol(r+2) > totalVol) hi = r;
			else lo = r;
		}
		cout << setprecision(5) 
		     << setiosflags(ios::fixed) 
			 << setiosflags(ios::showpoint) 
			 << r << endl;
		--nProbs;
	}
	fin.close();
	return 0;
}
