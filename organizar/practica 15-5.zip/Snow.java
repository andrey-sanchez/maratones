import java.util.*;
import java.io.File;

public class Snow{
	static String fname = "../test/snow.txt";
	public static void main(String[] args)throws Exception{
		checkData();
		Scanner sc = new Scanner(new File(fname)); 
		int nprobs = sc.nextInt();
		for(int prob=1; prob<=nprobs; prob++){
			
			double vol = sc.nextDouble();
			//doDum(vol);
			double lo=0.0, hi=1000.0;
			for(int i=0;i<200; i++){
				double mid = (lo+hi)/2.0;
				double req = sph(mid)+sph(mid+1)+sph(mid+2);
				if(req>vol) hi=mid; else lo=mid;				
			}
			System.out.printf("%.7f\n",lo);
		}
	}
	static void doDum(double vol){
		for(double r=0.0;  ; r += 0.00001){
			double q = r+0.000005;
			if(sph(q)+sph(q+1)+sph(q+2)> vol){
				System.out.printf("***%.5f\n",r);
				return;
			}
		}
	}
	static double sph(double r){
		return r*r*r*4*Math.PI/3;
	}
	//n   then n ints 50..200
	static void checkData()throws Exception{
		Scanner sc = new Scanner(new File(fname));
		String num=sc.nextLine();
		if(num.length() != num.trim().length())throw new Exception("a");
		int n = Integer.parseInt(num);
		for(int i=0;i<n;i++){
			String s = sc.nextLine();
			if(s.length() != s.trim().length()) throw new Exception("a"+i);
			int v = Integer.parseInt(s);
			if(v<50 || v>200) throw new Exception("v"+v);
		}
		if(sc.hasNext()) throw new Exception("b");
	} 
}