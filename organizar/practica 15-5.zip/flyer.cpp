#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>  //istringstream

using namespace std;

vector<string> a[50]; int na;  //a[0..na-1] are the data lines

int idx(string s){
	for(int i=0;i<na;i++) if(a[i][0]==s) return i;
	return -1; 
}

int main(int argc, char** argv){
	ifstream fin("../test/flyer.txt");
	int prob = 0;
	while(1){
		fin>>na; if(na<=0) break;

		cout << "Problem " << ++prob << ": ";
		string line; getline(fin,line); //end of first line		
		for(int i=0; i < na; ++i){
			a[i].clear();
			getline(fin, line);
			istringstream sin(line);
			string city;
			while(sin >> city) a[i].push_back(city);
		}
		int min[50]; for(int i=0;i<na;i++) min[i]=-1; //minsteps to i
		int here = idx("Vermillion");
		if(here>=0) min[here]=0;  //can get to Vermillion in 0 steps
		int ct=0, ans=-1;
		while( ans==-1 && ct<100 ){ //it can't take more than 20steps
			ct++;
			for(int i=0;i<na;i++) if(min[i]==ct-1){
				for(unsigned int j=1;j<a[i].size(); j++){
					if(a[i][j] == "Paris") ans=ct;
					int id = idx(a[i][j]);
					if(id>=0 && min[id]==-1) min[id]=ct;
				}
			}
		}
		if(ans<0) cout<<"Not Possible"<<endl; else cout<<ans<<endl;
	}
	fin.close();
	return 0;
}
