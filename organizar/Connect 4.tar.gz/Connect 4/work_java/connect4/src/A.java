import java.util.Locale;
import java.util.Scanner;

public class A {

	/**
	 * @param args
	 */
	int[] fib;
	int va = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new A();
	}

	public A() {
		Scanner in = new Scanner(System.in);

		int max = 25;

		fib = new int[max];
		fib[0] = 0;
		fib[1] = 1;
		va = 2;

		fibonacci(max);

		while (true) {
			int milla = in.nextInt();

			if (milla == 0)
				break;

			float res = resolver(milla, max - 1);

			System.out.format(Locale.US, "%.2f", res);
			System.out.println();
		}
	}

	public float resolver(int milla, int max) {
		float real = (float) milla * (float) 1.6;

		float menorError = milla * milla;

		for (int i = 2; i < max; i++) {
			if (milla == fib[i]) {
				menorError = Math.abs(real - fib[i + 1]);
			}
		}

		for (int i = 1; i <= 10; i++) {// cantidad de digitos
			float resultado = recursiva(2, i, milla, 0, 0, max, real);
			if (resultado >= 0) {
				if (resultado < menorError)
					menorError = resultado;
			}
		}
		return menorError;
	}

	float recursiva(int inicio, int digitos, int millas, int sumando,
			int kilometros, int max, float real) {
		float res = -1;

		if (sumando == millas) {
			return Math.abs(real - kilometros);
		}

		if (digitos > 0) {
			if (sumando < millas) {
				for (int i = inicio; i < max; i++) {
					if (sumando + fib[i] <= millas) {

						for (int j = 1;; j++) {
							if (sumando + (fib[i] * j) > millas)
								break;

							float aux = recursiva(i + 1, digitos - j, millas,
									sumando + (fib[i] * j), kilometros
											+ (fib[i + 1] * j), max, real);

							if (aux >= 0) {
								if (res < 0 || res > aux)
									res = aux;
								if (aux == 0)
									return 0;
							}
						}
					} else {
						break;
					}
				}
			}
		}

		return res;
	}

	public void fibonacci(int maximo) {

		for (; va < maximo; va++) {
			fib[va] = fib[va - 1] + fib[va - 2];
		}

		// for (int i = 0; i < maximo; i++)
		// System.out.println((i + 1) + " " + fib[i]);
	}

}
