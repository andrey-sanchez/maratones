import java.awt.geom.Line2D;
import java.util.Scanner;

public class D {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);

		while (true) {
			int rectas = in.nextInt();

			if (rectas == 0)
				break;

			int[] x1 = new int[rectas];
			int[] y1 = new int[rectas];
			int[] x2 = new int[rectas];
			int[] y2 = new int[rectas];

			Line2D[] lineas = new Line2D[rectas];

			for (int i = 0; i < rectas; i++) {
				x1[i] = in.nextInt();
				y1[i] = in.nextInt();
				x2[i] = in.nextInt();
				y2[i] = in.nextInt();

				lineas[i] = new Line2D.Float(x1[i], y1[i], x2[i], y2[i]);
			}

			System.out.println(cuentaIntersecciones(lineas, rectas));
		}

	}

	public static int cuentaIntersecciones(Line2D lineas[], int rectas) {
		int[] intersecciones = new int[rectas];
		int puntos = 0;
		for (int i = 0; i < rectas - 1; i++) {
			for (int j = i + 1; j < rectas; j++) {
				if (lineas[i].intersectsLine(lineas[j])
						|| lineas[i].getP1() == lineas[j].getP1()
						|| lineas[i].getP1() == lineas[j].getP2()
						|| lineas[i].getP2() == lineas[j].getP1()
						|| lineas[i].getP2() == lineas[j].getP2()) {
					intersecciones[i]++;
					intersecciones[j]++;
					puntos++;
				}
			}
		}

		int clavos = puntos;
		for (int i = 0; i < rectas; i++) {
			if (intersecciones[i] == 0)
				clavos += 2;
		}

		return clavos;
	}
}
