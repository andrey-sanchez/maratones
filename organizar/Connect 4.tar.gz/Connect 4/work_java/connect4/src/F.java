import java.util.Scanner;

public class F {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);

		while (true) {
			long k = in.nextLong();
			long m = in.nextLong();

			if (k == 0 && m == 0)
				break;

			boolean ban = false;

			int potencia = 0;

			for (int i = 0; i <= 10; i++) {
				potencia = i;

				if (Math.pow(2, i) == k) {
					ban = true;
					break;
				}

			}

			int nodos = (int) Math.pow(2, potencia);

			int v[] = new int[nodos];

			for (int i = 0; i < nodos; i++)
				v[i] = 0;

			for (int i = 0; i < m; i++) {
				long n1 = in.nextLong();
				long n2 = in.nextLong();

				if (n1 > k - 1) {
					ban = false;
					// break;
				} else {
					try {
						v[(int) n1]++;
						v[(int) n2]++;
					} catch (Exception ex) {
					}
				}

				long res = (n1 ^ n2);

				int cont = 0;
				for (int j = 0; j < 32; j++) {
					long ban2 = (res >> j) & 1;
					if (ban2 == 1)
						cont++;
				}

				if (cont != 1) {
					ban = false;
					// break;
				}
			}

			for (int i = 0; i < k; i++) {
				if (v[i] != potencia) {
					ban = false;
				}
			}

			String resultado = "YES";

			if (!ban)
				resultado = "NO";

			System.out.println(resultado);

		}

	}
}
