using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;
namespace Connect4NET
{
    class D
    {
        public bool interseccion(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
        {
         
            int xi=0, yi=0;
            try
            {
                xi = x3 * ((y4 - y3) / (x4 - x3)) * ((x2 - x1) / (y2 - y1));
                yi = y3 * ((x4 - x3) / (y4 - y3)) * ((y2 - y1) / (x2 - x1));
                return true;
            }
            catch(Exception E)
            {
                return false;
                //Console.WriteLine(E.Message);
            }
        }
        public int  cuentaIntersecciones(int[] x1, int[] y1, int[] x2, int[] y2, int rectas)
        {
            int[] intersecciones=new int[rectas];
            int puntos=0;
            for (int i = 0; i < rectas-1; i++)
            {   
                for (int j = i + 1; j < rectas; j++)
                {
                    if(interseccion(x1[i],y1[i],x2[i],y2[i],x1[j],y1[j],x2[j],y2[j]))
                    {
                        intersecciones[i]++;
                        intersecciones[j]++;
                        puntos++;
                    }
                }

            }
            int clavos=puntos;
            for (int i = 0; i < rectas; i++)
            {
                if (intersecciones[i] == 0)
                    clavos += 2;
            }
            return clavos;
        }
        public D()
        {
            while (true)
            {
                int rectas = int.Parse(Console.ReadLine());

                if (rectas == 0)
                    break;

                int[] x1 = new int[rectas];
                int[] y1 = new int[rectas];
                int[] x2 = new int[rectas];
                int[] y2 = new int[rectas];

                for (int i = 0; i < rectas; i++)
                {
                    String[] aux = Console.ReadLine().Split();
                    x1[i] = int.Parse(aux[0]);
                    y1[i] = int.Parse(aux[1]);
                    x2[i] = int.Parse(aux[2]);
                    y2[i] = int.Parse(aux[3]);

                }
                System.Console.WriteLine(cuentaIntersecciones(x1, y1, x2, y2, rectas));



            }




        }
        static void Main(string[] args)
        {
            D p = new D();
            
        }
    }
}
