using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;


namespace calentamiento
{
    class B
    {
        static void Main(string[] args)
        {
            try
            {
                //StreamReader lector = new StreamReader(System.Console);

                //Console.ReadLine();

                int casos = int.Parse(Console.ReadLine());

                String linea = Console.ReadLine();

                CultureInfo MyCultureInfo = new CultureInfo("en-US");

                DateTime actual = DateTime.Parse(linea, MyCultureInfo);

                for (int i = 0; i < casos; i++)
                {
                    DateTime fecha = DateTime.Parse(Console.ReadLine(), MyCultureInfo);

                    TimeSpan dif = actual - fecha;

                    String resultado = "";

                    if (dif.Days >= 365)
                    {//a�os
                        int campo = dif.Days / 365;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " year" + aux + " ago";
                    }
                    else if (dif.Days > 6 * 7)
                    { //meses
                        int campo = dif.Days / 30;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " month" + aux + " ago";
                    }
                    else if (dif.Days > 7)
                    {//semanas
                        int campo = dif.Days / 7;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " week" + aux + " ago";
                    }
                    else if (dif.Days >= 1)
                    {//dias
                        int campo = dif.Days;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " day" + aux + " ago";
                    }
                    else if (dif.Hours >= 1)
                    {//horas
                        int campo = dif.Hours;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " hour" + aux + " ago";
                    }
                    else if (dif.Minutes >= 1)
                    {//minutos
                        int campo = dif.Minutes;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " minute" + aux + " ago";
                    }
                    else
                    {//segundos
                        int campo = dif.Seconds;
                        String aux = "";
                        if (campo != 1)
                            aux = "s";
                        resultado = campo + " second" + aux + " ago";
                    }

                    System.Console.WriteLine(resultado);

                }


            }
            catch (Exception) { }

        }


        static int recursiva(int antI, int antJ, int ant)
        {
            int cont = 0;
            if (matriz[antI][antJ] != ant)
                return 0;

            cont = 1;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    int ant = matriz[i, j];
                    matriz[i, j] = -1;
                    int aux = recursiva(i, j + 1, ant) + 1;
                    if (aux > cont)
                        cont = aux;
                    aux = recursiva(i, j - 1, ant) + 1;
                    if (aux > cont)
                        cont = aux;
                    aux = recursiva(i + 1, j, ant) + 1;
                    if (aux > cont)
                        cont = aux;
                    aux = recursiva(i - 1, j + 1, ant) + 1;
                    if (aux > cont)
                        cont = aux;

                }
            }

            return cont;
        }

    }
}
