#include <iostream>
using namespace std;

// dynamic solution: solve for
//
//  c(i,j) = best Player 1 can do for sequence of length 2i starting at j
//
const int MAXSIZE = 1000;

int seq[MAXSIZE];

int table[MAXSIZE/2+1][MAXSIZE-1];

int main()
{
	int n, i, j;
	int game=0;
	cin >> n;
	while (n != 0) {
		game++;
		cin >> seq[0];
		for(i=1; i<n; i++) {
			cin >> seq[i];
			if (seq[i] > seq[i-1])
				table[1][i-1] = seq[i] - seq[i-1];
			else
				table[1][i-1] = seq[i-1] - seq[i];
		}
		for(i=2; i<=n/2; i++) {
			for(j=0; j<n-2*i+1; j++) {
				int val1;					// result if player 1 picks left end
				if (seq[j+2*i-1] > seq[j+1])
					val1 = seq[j] - seq[j+2*i-1] + table[i-1][j+1];
				else
					val1 = seq[j] - seq[j+1] + table[i-1][j+2];
				int val2;					// result if player 2 picks right end
				if (seq[j+2*i-2] > seq[j])
					val2 = seq[j+2*i-1] - seq[j+2*i-2] + table[i-1][j];
				else
					val2 = seq[j+2*i-1] - seq[j] + table[i-1][j+1];

				if (val1 > val2)
					table[i][j] = val1;
				else
					table[i][j] = val2;
			}
		}
		cout << "In game " << game << ", the greedy strategy might lose by as many as " << table[n/2][0] << " points." << endl;

		cin >> n;
	}
return 0;
}

