// Solution to "Swamp Things" by Bob Roos
// This is a straightforward triple-nested-loop with no attempt at
// improving efficiency; at n = 1000 it crawls.

import java.io.*;
import java.util.*;

public class SwampFinal {
  public static BufferedReader in;
  public static int photoNum;
  public static int n;
  public static int[] x;
  public static int[] y;

  public static void main(String[] args) throws IOException {
    in = new BufferedReader(new InputStreamReader(System.in));
    photoNum = 0;
    String line;
    while (!(line = in.readLine().trim()).equals("0")) {
      photoNum++;
      n = Integer.parseInt(line);
      x = new int[n];
      y = new int[n];
      for (int i = 0; i < n; i++) {
        line = in.readLine().trim();
        StringTokenizer tok = new StringTokenizer(line);
        x[i] = Integer.parseInt(tok.nextToken());
        y[i] = Integer.parseInt(tok.nextToken());
      }
      System.out.println("Photo " + photoNum + ": " + process() 
                + " points eliminated");
    }
  }

  public static int process() {
    int maxCount = 0;
    for (int i = 0; i < n-1; i++) {
      for (int j = i+1; j < n; j++) {
        int count = 2;
        int rise = y[j] - y[i];
        int run = x[j] - x[i];
        for (int k = j+1; k < n; k++) {
          if (k == i || k == j)
             continue;
          int rise1 = y[k] - y[i];
          int run1 = x[k] - x[i];
          if (rise*run1 == rise1*run) 
            count++;
        }
        if (count >= 4 && count > maxCount)
          maxCount = count;
      }
    }
    return maxCount;
  }
}
