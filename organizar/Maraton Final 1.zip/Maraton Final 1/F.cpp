#include <iostream>
using namespace std;

const int MAXNUM = 1000;

struct rect
{
	long x1, y1, x2, y2;
} rects[MAXNUM];

long mult(long a, long b, long c)
//
// preform the multiplication abc/6 when abc may cause overflow
//
{
	if (a%2 == 0)
		a /= 2;
	else if (b%2 == 0)
		b /= 2;
	else if (c%2 == 0)
		c /= 2;
	else
		cout << "ERROR: none divisble by 2" << endl;	// should never happen
	if (a%3 == 0)
		a /= 3;
	else if (b%3 == 0)
		b /= 3;
	else if (c%3 == 0)
		c /= 3;
	else
		cout << "ERROR: none divisble by 3" << endl;	// should never happen
	if (a*b*c <= 0)
		cout << "ERROR: overflow in multiplication" << endl;
//cout << "abc = " << a*b*c << endl;
	return a*b*c;
}

long numSquares(long n, long m)
//
// returns number of squares in an n x m room
//
{
cout << "numSquare: n, m = " << n << ',' << m << endl;
	if (n > m)
		return mult((3*n-m+1),m,m+1);
	else
		return mult((3*m-n+1),n,n+1);
}

long min(long a, long b)
{
	if (a<b)
		return a;
	else
		return b;
}

bool intersection(long a, long b, long c, long d, long& len)
{
	len = 0;
	if (c >= a && c <= b) {
		len = min(b,d) - c;
	}
	else if (a >= c && a <= d) {
		len = min(b,d) - a;
	}
	len -= 2;
	return (len > 1);
}

long crossSquares(int r1, int r2)
//
// returns number of squares lying between rectangles r1 and r2
//
{
	long len;
	if (intersection(rects[r1].x1, rects[r1].x2, rects[r2].x1, rects[r2].x2, len)) {
		if (rects[r1].y2 == rects[r2].y1) {
//cout << "intersection found between " << r1 <<',' << r2 << "along x with length " << len << endl;
			return numSquares(len, rects[r2].y2 - rects[r1].y1) -
				   numSquares(len, rects[r2].y2 - rects[r2].y1) -
				   numSquares(len, rects[r1].y2 - rects[r1].y1);
		}
		else if (rects[r2].y2 == rects[r1].y1) {
//cout << "intersection found between " << r1 <<',' << r2 << "along x with length " << len << endl;
			return numSquares(len, rects[r1].y2 - rects[r2].y1) -
				   numSquares(len, rects[r2].y2 - rects[r2].y1) -
				   numSquares(len, rects[r1].y2 - rects[r1].y1);
		}
	}
	else if  (intersection(rects[r1].y1, rects[r1].y2, rects[r2].y1, rects[r2].y2, len)) {
		if (rects[r1].x2 == rects[r2].x1) {
//cout << "intersection found between " << r1 <<',' << r2 << "along y with length " << len << endl;
			return numSquares(len, rects[r2].x2 - rects[r1].x1) -
				   numSquares(len, rects[r2].x2 - rects[r2].x1) -
				   numSquares(len, rects[r1].x2 - rects[r1].x1);
		}
		else if (rects[r2].x2 == rects[r1].x1) {
//cout << "intersection found between " << r1 <<',' << r2 << "along y with length " << len << endl;
			return numSquares(len, rects[r1].x2 - rects[r2].x1) -
				   numSquares(len, rects[r2].x2 - rects[r2].x1) -
				   numSquares(len, rects[r1].x2 - rects[r1].x1);
		}
	}
	return 0;
}

int main()
{
	int i, j,  n, icase=0;
	cin >> n;
	while (n != 0) {
		icase++;
		long sum = 0;
		for(i=0; i<n; i++) {
			cin >> rects[i].x1 >> rects[i].y1 >> rects[i].x2 >> rects[i].y2;
			if (rects[i].x1 > rects[i].x2) {  // insure lower left in x1,y1
				int temp = rects[i].x1;
				rects[i].x1 = rects[i].x2;
				rects[i].x2 = temp;
			}
			if (rects[i].y1 > rects[i].y2) {
				int temp = rects[i].y1;
				rects[i].y1 = rects[i].y2;
				rects[i].y2 = temp;
			}
			sum += numSquares(rects[i].x2-rects[i].x1, rects[i].y2-rects[i].y1);
cout << i << ',' << numSquares(rects[i].x2-rects[i].x1, rects[i].y2-rects[i].y1) << endl;
		}
		for(i=0; i<n-1; i++) {
			for(j=i+1; j<n; j++) {
				sum += crossSquares(i, j);
if (crossSquares(i, j) > 0) cout << i << ',' << j << ',' << crossSquares(i, j) << endl;
			}
		}
		cout << "Case " << icase << ": " << sum << endl;

		cin >> n;
	}
return 0;
}

